﻿Public Class Producto
    Public Property Id As Integer
    Public Property CodigoBarra As String
    Public Property Descripcion As String
    Public Property Costo As Decimal
    Public Property Precio As Decimal
    Public Property ITBMS As Integer
    Public Property Existencia As Integer
    Public Property PuntoDeReorden As Integer
    Public Property Estatus As Char
End Class
