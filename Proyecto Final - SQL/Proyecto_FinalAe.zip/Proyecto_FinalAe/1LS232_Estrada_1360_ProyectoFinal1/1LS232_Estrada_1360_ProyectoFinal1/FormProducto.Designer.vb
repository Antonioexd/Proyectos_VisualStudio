﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormProducto
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtCodigoBarra = New TextBox()
        Label1 = New Label()
        txtDescripcion = New TextBox()
        Label2 = New Label()
        txtCosto = New TextBox()
        Label3 = New Label()
        txtPrecio = New TextBox()
        Label4 = New Label()
        txtITBMS = New TextBox()
        Label5 = New Label()
        txtExistencia = New TextBox()
        Label6 = New Label()
        txtPuntoReorden = New TextBox()
        Label7 = New Label()
        Label8 = New Label()
        btnBuscar = New Button()
        btnAgregar = New Button()
        btnModificar = New Button()
        btnEliminar = New Button()
        btnListar = New Button()
        btnLimpiar = New Button()
        dgvProductos = New DataGridView()
        Label9 = New Label()
        chkActivo = New CheckBox()
        chkInactivo = New CheckBox()
        chkOrdenCodigo = New CheckBox()
        chkOrdenDescripcion = New CheckBox()
        CType(dgvProductos, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtCodigoBarra
        ' 
        txtCodigoBarra.Location = New Point(12, 12)
        txtCodigoBarra.Name = "txtCodigoBarra"
        txtCodigoBarra.Size = New Size(125, 27)
        txtCodigoBarra.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(143, 19)
        Label1.Name = "Label1"
        Label1.Size = New Size(118, 20)
        Label1.TabIndex = 1
        Label1.Text = "Código de Barra"
        ' 
        ' txtDescripcion
        ' 
        txtDescripcion.Location = New Point(12, 56)
        txtDescripcion.Name = "txtDescripcion"
        txtDescripcion.Size = New Size(125, 27)
        txtDescripcion.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(143, 63)
        Label2.Name = "Label2"
        Label2.Size = New Size(87, 20)
        Label2.TabIndex = 3
        Label2.Text = "Descripción"
        ' 
        ' txtCosto
        ' 
        txtCosto.Location = New Point(12, 101)
        txtCosto.Name = "txtCosto"
        txtCosto.Size = New Size(125, 27)
        txtCosto.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(143, 108)
        Label3.Name = "Label3"
        Label3.Size = New Size(47, 20)
        Label3.TabIndex = 5
        Label3.Text = "Costo"
        ' 
        ' txtPrecio
        ' 
        txtPrecio.Location = New Point(12, 147)
        txtPrecio.Name = "txtPrecio"
        txtPrecio.Size = New Size(125, 27)
        txtPrecio.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(143, 154)
        Label4.Name = "Label4"
        Label4.Size = New Size(50, 20)
        Label4.TabIndex = 7
        Label4.Text = "Precio"
        ' 
        ' txtITBMS
        ' 
        txtITBMS.Location = New Point(12, 192)
        txtITBMS.Name = "txtITBMS"
        txtITBMS.Size = New Size(125, 27)
        txtITBMS.TabIndex = 8
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(143, 195)
        Label5.Name = "Label5"
        Label5.Size = New Size(51, 20)
        Label5.TabIndex = 9
        Label5.Text = "ITBMS"
        ' 
        ' txtExistencia
        ' 
        txtExistencia.Location = New Point(12, 234)
        txtExistencia.Name = "txtExistencia"
        txtExistencia.Size = New Size(125, 27)
        txtExistencia.TabIndex = 10
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(143, 241)
        Label6.Name = "Label6"
        Label6.Size = New Size(74, 20)
        Label6.TabIndex = 11
        Label6.Text = "Existencia"
        ' 
        ' txtPuntoReorden
        ' 
        txtPuntoReorden.Location = New Point(12, 280)
        txtPuntoReorden.Name = "txtPuntoReorden"
        txtPuntoReorden.Size = New Size(125, 27)
        txtPuntoReorden.TabIndex = 12
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(143, 287)
        Label7.Name = "Label7"
        Label7.Size = New Size(128, 20)
        Label7.TabIndex = 13
        Label7.Text = "Punto de Reorden"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Location = New Point(27, 320)
        Label8.Name = "Label8"
        Label8.Size = New Size(55, 20)
        Label8.TabIndex = 14
        Label8.Text = "Estatus"
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Location = New Point(694, 10)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(94, 29)
        btnBuscar.TabIndex = 17
        btnBuscar.Text = "Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Location = New Point(694, 54)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(94, 29)
        btnAgregar.TabIndex = 18
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' btnModificar
        ' 
        btnModificar.Location = New Point(694, 99)
        btnModificar.Name = "btnModificar"
        btnModificar.Size = New Size(94, 29)
        btnModificar.TabIndex = 19
        btnModificar.Text = "Modificar"
        btnModificar.UseVisualStyleBackColor = True
        ' 
        ' btnEliminar
        ' 
        btnEliminar.Location = New Point(694, 145)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(94, 29)
        btnEliminar.TabIndex = 20
        btnEliminar.Text = "Eliminar"
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' btnListar
        ' 
        btnListar.Location = New Point(694, 190)
        btnListar.Name = "btnListar"
        btnListar.Size = New Size(94, 29)
        btnListar.TabIndex = 21
        btnListar.Text = "Listar"
        btnListar.UseVisualStyleBackColor = True
        ' 
        ' btnLimpiar
        ' 
        btnLimpiar.Location = New Point(694, 232)
        btnLimpiar.Name = "btnLimpiar"
        btnLimpiar.Size = New Size(94, 29)
        btnLimpiar.TabIndex = 22
        btnLimpiar.Text = "Limpiar"
        btnLimpiar.UseVisualStyleBackColor = True
        ' 
        ' dgvProductos
        ' 
        dgvProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvProductos.Location = New Point(277, 19)
        dgvProductos.Name = "dgvProductos"
        dgvProductos.RowHeadersWidth = 51
        dgvProductos.Size = New Size(411, 288)
        dgvProductos.TabIndex = 23
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(171, 320)
        Label9.Name = "Label9"
        Label9.Size = New Size(90, 20)
        Label9.TabIndex = 24
        Label9.Text = "Ordenar por"
        ' 
        ' chkActivo
        ' 
        chkActivo.AutoSize = True
        chkActivo.Location = New Point(27, 343)
        chkActivo.Name = "chkActivo"
        chkActivo.Size = New Size(73, 24)
        chkActivo.TabIndex = 27
        chkActivo.Text = "Activo"
        chkActivo.UseVisualStyleBackColor = True
        ' 
        ' chkInactivo
        ' 
        chkInactivo.AutoSize = True
        chkInactivo.Location = New Point(27, 364)
        chkInactivo.Name = "chkInactivo"
        chkInactivo.Size = New Size(83, 24)
        chkInactivo.TabIndex = 28
        chkInactivo.Text = "Inactivo"
        chkInactivo.UseVisualStyleBackColor = True
        ' 
        ' chkOrdenCodigo
        ' 
        chkOrdenCodigo.AutoSize = True
        chkOrdenCodigo.Location = New Point(171, 343)
        chkOrdenCodigo.Name = "chkOrdenCodigo"
        chkOrdenCodigo.Size = New Size(140, 24)
        chkOrdenCodigo.TabIndex = 29
        chkOrdenCodigo.Text = "Codigo de Barra"
        chkOrdenCodigo.UseVisualStyleBackColor = True
        ' 
        ' chkOrdenDescripcion
        ' 
        chkOrdenDescripcion.AutoSize = True
        chkOrdenDescripcion.Location = New Point(171, 364)
        chkOrdenDescripcion.Name = "chkOrdenDescripcion"
        chkOrdenDescripcion.Size = New Size(109, 24)
        chkOrdenDescripcion.TabIndex = 30
        chkOrdenDescripcion.Text = "Descripcion"
        chkOrdenDescripcion.UseVisualStyleBackColor = True
        ' 
        ' FormProducto
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(chkOrdenDescripcion)
        Controls.Add(chkOrdenCodigo)
        Controls.Add(chkInactivo)
        Controls.Add(chkActivo)
        Controls.Add(Label9)
        Controls.Add(dgvProductos)
        Controls.Add(btnLimpiar)
        Controls.Add(btnListar)
        Controls.Add(btnEliminar)
        Controls.Add(btnModificar)
        Controls.Add(btnAgregar)
        Controls.Add(btnBuscar)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(txtPuntoReorden)
        Controls.Add(Label6)
        Controls.Add(txtExistencia)
        Controls.Add(Label5)
        Controls.Add(txtITBMS)
        Controls.Add(Label4)
        Controls.Add(txtPrecio)
        Controls.Add(Label3)
        Controls.Add(txtCosto)
        Controls.Add(Label2)
        Controls.Add(txtDescripcion)
        Controls.Add(Label1)
        Controls.Add(txtCodigoBarra)
        Name = "FormProducto"
        Text = "FormProducto"
        CType(dgvProductos, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtCodigoBarra As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtDescripcion As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtCosto As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtPrecio As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtITBMS As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtExistencia As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents txtPuntoReorden As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents btnModificar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnListar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents dgvProductos As DataGridView
    Friend WithEvents Label9 As Label
    Friend WithEvents chkActivo As CheckBox
    Friend WithEvents chkInactivo As CheckBox
    Friend WithEvents chkOrdenCodigo As CheckBox
    Friend WithEvents chkOrdenDescripcion As CheckBox
End Class
