﻿Public Class Form1
    ' Evento al cargar el formulario principal
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.IsMdiContainer = True ' Configura el formulario como contenedor MDI
    End Sub

    ' Evento para abrir el formulario de Presentación
    Private Sub PresentacionToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PresentacionToolStripMenuItem.Click
        ' Verifica si el formulario ya está abierto
        For Each form As Form In Me.MdiChildren
            If TypeOf form Is FormPresentacion Then
                form.Activate() ' Activa el formulario si ya está abierto
                Return
            End If
        Next

        ' Verifica que la clase FormPresentacion exista antes de usarla
        Try
            Dim formPresentacion As New FormPresentacion()
            formPresentacion.MdiParent = Me ' Configura como hijo MDI
            formPresentacion.Show() ' Muestra el formulario
        Catch ex As Exception
            MessageBox.Show("Error al abrir el formulario de Presentación: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Evento para abrir el formulario de Clientes
    Private Sub ClienteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClienteToolStripMenuItem.Click
        ' Verifica si el formulario ya está abierto
        For Each form As Form In Me.MdiChildren
            If TypeOf form Is FormCliente Then
                form.Activate() ' Si está abierto, actívalo
                Return
            End If
        Next

        Try
            Dim formCliente As New FormCliente() ' Crea una instancia del formulario de clientes
            formCliente.MdiParent = Me ' Configura como hijo MDI
            formCliente.Show()
        Catch ex As Exception
            MessageBox.Show("Error al abrir el formulario de Clientes: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Evento para abrir el formulario de Productos
    Private Sub ProductoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProductoToolStripMenuItem.Click
        ' Verifica si el formulario ya está abierto
        For Each form As Form In Me.MdiChildren
            If TypeOf form Is FormProducto Then
                form.Activate() ' Si está abierto, actívalo
                Return
            End If
        Next

        Try
            Dim formProducto As New FormProducto() ' Crea una instancia del formulario de productos
            formProducto.MdiParent = Me ' Configura como hijo MDI
            formProducto.Show()
        Catch ex As Exception
            MessageBox.Show("Error al abrir el formulario de Productos: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Evento para salir de la aplicación
    Private Sub SalirToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalirToolStripMenuItem.Click
        If MessageBox.Show("¿Deseas salir de la aplicación?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            Application.Exit() ' Cierra la aplicación
        End If
    End Sub

    ' Botón para probar la conexión con la base de datos
    Private Sub btnProbarConexion_Click(sender As Object, e As EventArgs) Handles btnProbarConexion.Click
        Try
            Dim bd As New BD() ' Instancia de la clase BD

            ' Verifica si el método ProbarConexion está implementado en la clase BD
            If bd.ProbarConexion() Then
                MessageBox.Show("Conexión exitosa a la base de datos.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                MessageBox.Show("Error al conectar con la base de datos. Verifica la configuración.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Catch ex As Exception
            MessageBox.Show("Error al probar la conexión con la base de datos: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class
