﻿Imports System.Data.SqlClient

Public Class FormProducto
    Private BD As New BD() ' Instancia de la clase para conexión a la base de datos

    ' Evento que se ejecuta al cargar el formulario
    Private Sub FormProducto_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LimpiarCampos()
    End Sub

    ' Botón para buscar un producto
    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        If String.IsNullOrWhiteSpace(txtCodigoBarra.Text) Then
            MessageBox.Show("Por favor, ingresa un código de barra para buscar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim parametros As New List(Of SqlParameter) From {
            New SqlParameter("@codigoBarra", txtCodigoBarra.Text)
        }

        Try
            Dim resultado As DataTable = BD.EjecutarSP("BuscarProducto", parametros)

            If resultado.Rows.Count > 0 Then
                txtDescripcion.Text = resultado.Rows(0)("descripcion").ToString()
                txtCosto.Text = resultado.Rows(0)("costo").ToString()
                txtPrecio.Text = resultado.Rows(0)("precio").ToString()
                txtITBMS.Text = resultado.Rows(0)("itbms").ToString()
                txtExistencia.Text = resultado.Rows(0)("existencia").ToString()
                txtPuntoReorden.Text = resultado.Rows(0)("puntoReorden").ToString()
                chkActivo.Checked = (resultado.Rows(0)("estatus").ToString() = "A")
                chkInactivo.Checked = (resultado.Rows(0)("estatus").ToString() = "I")

                btnAgregar.Enabled = False
                btnModificar.Enabled = True
                btnEliminar.Enabled = True
            Else
                MessageBox.Show("Producto no encontrado. Puedes agregarlo.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LimpiarCampos()
                btnAgregar.Enabled = True
                btnModificar.Enabled = False
                btnEliminar.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show("Error al buscar producto: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para agregar un producto
    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        If Not ValidarCampos() Then
            Return
        End If

        Dim parametros As New List(Of SqlParameter) From {
            New SqlParameter("@codigoBarra", txtCodigoBarra.Text),
            New SqlParameter("@descripcion", txtDescripcion.Text),
            New SqlParameter("@costo", Convert.ToDecimal(txtCosto.Text)),
            New SqlParameter("@precio", Convert.ToDecimal(txtPrecio.Text)),
            New SqlParameter("@itbms", Convert.ToInt32(txtITBMS.Text)),
            New SqlParameter("@existencia", Convert.ToInt32(txtExistencia.Text)),
            New SqlParameter("@puntodereorden", Convert.ToInt32(txtPuntoReorden.Text)),
            New SqlParameter("@estatus", If(chkActivo.Checked, "A", "I"))
        }

        Try
            BD.EjecutarSPNonQuery("AgregarProducto", parametros)
            MessageBox.Show("Producto agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LimpiarCampos()
            CargarLista()
        Catch ex As Exception
            MessageBox.Show("Error al agregar producto: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para modificar un producto
    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        If Not ValidarCampos() Then
            Return
        End If

        Dim parametros As New List(Of SqlParameter) From {
            New SqlParameter("@codigoBarra", txtCodigoBarra.Text),
            New SqlParameter("@descripcion", txtDescripcion.Text),
            New SqlParameter("@costo", Convert.ToDecimal(txtCosto.Text)),
            New SqlParameter("@precio", Convert.ToDecimal(txtPrecio.Text)),
            New SqlParameter("@itbms", Convert.ToInt32(txtITBMS.Text)),
            New SqlParameter("@existencia", Convert.ToInt32(txtExistencia.Text)),
            New SqlParameter("@puntodereorden", Convert.ToInt32(txtPuntoReorden.Text)),
            New SqlParameter("@estatus", If(chkActivo.Checked, "A", "I"))
        }

        Try
            BD.EjecutarSPNonQuery("ModificarProducto", parametros)
            MessageBox.Show("Producto modificado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LimpiarCampos()
            CargarLista()
        Catch ex As Exception
            MessageBox.Show("Error al modificar producto: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para eliminar un producto
    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        If String.IsNullOrWhiteSpace(txtCodigoBarra.Text) Then
            MessageBox.Show("Por favor, selecciona un producto para eliminar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        Dim confirmacion As DialogResult = MessageBox.Show("¿Estás seguro de que deseas eliminar este producto?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If confirmacion = DialogResult.No Then
            Return
        End If

        Dim parametros As New List(Of SqlParameter) From {
            New SqlParameter("@codigoBarra", txtCodigoBarra.Text)
        }

        Try
            BD.EjecutarSPNonQuery("EliminarProducto", parametros)
            MessageBox.Show("Producto eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LimpiarCampos()
            CargarLista()
        Catch ex As Exception
            MessageBox.Show("Error al eliminar producto: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para listar todos los productos
    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        CargarLista()
    End Sub

    ' Método para cargar la lista de productos en el DataGridView
    Private Sub CargarLista()
        Try
            Dim dt As DataTable = BD.EjecutarSP("ListarProductos", Nothing)
            dgvProductos.DataSource = dt
        Catch ex As Exception
            MessageBox.Show("Error al listar productos: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Método para limpiar los campos del formulario
    Private Sub LimpiarCampos()
        txtCodigoBarra.Text = ""
        txtDescripcion.Text = ""
        txtCosto.Text = ""
        txtPrecio.Text = ""
        txtITBMS.Text = ""
        txtExistencia.Text = ""
        txtPuntoReorden.Text = ""
        chkActivo.Checked = False
        chkInactivo.Checked = False
    End Sub

    ' Método para validar los campos antes de ejecutar cualquier acción
    Private Function ValidarCampos() As Boolean
        If String.IsNullOrWhiteSpace(txtCodigoBarra.Text) OrElse
           String.IsNullOrWhiteSpace(txtDescripcion.Text) OrElse
           String.IsNullOrWhiteSpace(txtCosto.Text) OrElse
           String.IsNullOrWhiteSpace(txtPrecio.Text) OrElse
           String.IsNullOrWhiteSpace(txtITBMS.Text) OrElse
           String.IsNullOrWhiteSpace(txtExistencia.Text) OrElse
           String.IsNullOrWhiteSpace(txtPuntoReorden.Text) Then
            MessageBox.Show("Por favor, completa todos los campos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        If Not IsNumeric(txtCosto.Text) OrElse Not IsNumeric(txtPrecio.Text) OrElse
           Not IsNumeric(txtITBMS.Text) OrElse Not IsNumeric(txtExistencia.Text) OrElse Not IsNumeric(txtPuntoReorden.Text) Then
            MessageBox.Show("Los campos Costo, Precio, ITBMS, Existencia y Punto de Reorden deben ser numéricos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function
End Class
