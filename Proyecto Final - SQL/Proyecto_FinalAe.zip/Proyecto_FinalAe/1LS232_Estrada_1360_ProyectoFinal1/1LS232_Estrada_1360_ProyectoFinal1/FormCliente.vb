﻿Imports System.Data.SqlClient

Public Class FormCliente
    Private BD As New BD() ' Instancia de la clase de conexión a la base de datos

    ' Evento al cargar el formulario
    Private Sub FormCliente_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LimpiarCampos()
    End Sub

    ' Botón para buscar un cliente
    Private Sub btnBuscar_Click(sender As Object, e As EventArgs) Handles btnBuscar.Click
        ' Validar que el campo de búsqueda no esté vacío
        If String.IsNullOrWhiteSpace(txtCedula.Text) Then
            MessageBox.Show("Por favor, ingresa una cédula para buscar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Crear los parámetros para la búsqueda
        Dim parametros As New List(Of SqlParameter) From {
            New SqlParameter("@cedula", txtCedula.Text)
        }

        Try
            ' Ejecutar el procedimiento almacenado para buscar el cliente
            Dim resultado As DataTable = BD.EjecutarSP("BuscarCliente", parametros)

            If resultado.Rows.Count > 0 Then
                ' Si se encuentra el cliente, cargar los datos en los controles
                txtNombre.Text = resultado.Rows(0)("nombre").ToString()
                txtApellido.Text = resultado.Rows(0)("apellido").ToString()
                txtDireccion.Text = resultado.Rows(0)("direccion").ToString()
                txtCelular.Text = resultado.Rows(0)("celular").ToString()
                txtCorreo.Text = resultado.Rows(0)("correo").ToString()
                chkMasculino.Checked = (resultado.Rows(0)("sexo").ToString() = "M")
                chkFemenino.Checked = (resultado.Rows(0)("sexo").ToString() = "F")
                chkActivo.Checked = (resultado.Rows(0)("estatus").ToString() = "A")
                chkInactivo.Checked = (resultado.Rows(0)("estatus").ToString() = "I")

                ' Habilitar o deshabilitar botones
                btnAgregar.Enabled = False
                btnModificar.Enabled = True
                btnEliminar.Enabled = True
            Else
                ' Si no se encuentra el cliente, mostrar mensaje
                MessageBox.Show("Cliente no encontrado. Puedes agregarlo.", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information)
                LimpiarCampos()
                btnAgregar.Enabled = True
                btnModificar.Enabled = False
                btnEliminar.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show("Error al buscar cliente: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para agregar un cliente
    Private Sub btnAgregar_Click(sender As Object, e As EventArgs) Handles btnAgregar.Click
        ' Validar campos antes de proceder
        If Not ValidarCampos() Then
            MessageBox.Show("Por favor, completa todos los campos correctamente.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Crear los parámetros para el procedimiento almacenado
        Dim parametros As New List(Of SqlParameter) From {
            New SqlParameter("@cedula", txtCedula.Text),
            New SqlParameter("@nombre", txtNombre.Text),
            New SqlParameter("@apellido", txtApellido.Text),
            New SqlParameter("@direccion", txtDireccion.Text),
            New SqlParameter("@celular", txtCelular.Text),
            New SqlParameter("@correo", txtCorreo.Text),
            New SqlParameter("@sexo", If(chkMasculino.Checked, "M", "F")),
            New SqlParameter("@estatus", If(chkActivo.Checked, "A", "I"))
        }

        Try
            ' Ejecutar el procedimiento almacenado para agregar cliente
            BD.EjecutarSPNonQuery("AgregarCliente", parametros)
            MessageBox.Show("Cliente agregado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LimpiarCampos()
            CargarLista() ' Refresca la lista después de agregar
        Catch ex As Exception
            MessageBox.Show("Error al agregar cliente: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para modificar un cliente
    Private Sub btnModificar_Click(sender As Object, e As EventArgs) Handles btnModificar.Click
        ' Validar campos antes de proceder
        If Not ValidarCampos() Then
            MessageBox.Show("Por favor, completa todos los campos correctamente.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Crear los parámetros para el procedimiento almacenado
        Dim parametros As New List(Of SqlParameter) From {
            New SqlParameter("@cedula", txtCedula.Text),
            New SqlParameter("@nombre", txtNombre.Text),
            New SqlParameter("@apellido", txtApellido.Text),
            New SqlParameter("@direccion", txtDireccion.Text),
            New SqlParameter("@celular", txtCelular.Text),
            New SqlParameter("@correo", txtCorreo.Text),
            New SqlParameter("@sexo", If(chkMasculino.Checked, "M", "F")),
            New SqlParameter("@estatus", If(chkActivo.Checked, "A", "I"))
        }

        Try
            ' Ejecutar el procedimiento almacenado para modificar el cliente
            BD.EjecutarSPNonQuery("ModificarCliente", parametros)
            MessageBox.Show("Cliente modificado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LimpiarCampos()
            CargarLista() ' Refresca la lista después de modificar
        Catch ex As Exception
            MessageBox.Show("Error al modificar cliente: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para listar clientes
    Private Sub btnListar_Click(sender As Object, e As EventArgs) Handles btnListar.Click
        CargarLista()
    End Sub

    ' Método para cargar la lista de clientes en el DataGridView
    Private Sub CargarLista()
        Try
            Dim orden As String = If(chkOrdenCedula.Checked, "cedula", "nombre") ' Determina el orden
            Dim parametros As New List(Of SqlParameter) From {
                New SqlParameter("@orden", orden)
            }

            ' Ejecuta el procedimiento almacenado para listar clientes
            Dim dt As DataTable = BD.EjecutarSP("ListarClientes", parametros)
            dgvClientes.DataSource = dt
        Catch ex As Exception
            MessageBox.Show("Error al listar clientes: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' Botón para limpiar los campos
    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        LimpiarCampos()
    End Sub

    ' Botón para eliminar un cliente
    Private Sub btnEliminar_Click(sender As Object, e As EventArgs) Handles btnEliminar.Click
        ' Validar que el campo de cédula no esté vacío
        If String.IsNullOrWhiteSpace(txtCedula.Text) Then
            MessageBox.Show("Por favor, selecciona un cliente para eliminar.", "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Confirmar eliminación
        Dim confirmacion As DialogResult = MessageBox.Show("¿Estás seguro de que deseas eliminar este cliente?", "Confirmación", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If confirmacion = DialogResult.No Then
            Return
        End If

        ' Crear los parámetros para el procedimiento almacenado
        Dim parametros As New List(Of SqlParameter) From {
        New SqlParameter("@cedula", txtCedula.Text)
    }

        Try
            ' Ejecutar el procedimiento almacenado para eliminar cliente
            BD.EjecutarSPNonQuery("EliminarCliente", parametros)
            MessageBox.Show("Cliente eliminado correctamente.", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information)
            LimpiarCampos()
            CargarLista() ' Refresca la lista después de eliminar
        Catch ex As Exception
            MessageBox.Show("Error al eliminar cliente: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    ' Método para limpiar los campos del formulario
    Private Sub LimpiarCampos()
        txtCedula.Text = ""
        txtNombre.Text = ""
        txtApellido.Text = ""
        txtDireccion.Text = ""
        txtCelular.Text = ""
        txtCorreo.Text = ""
        chkMasculino.Checked = False
        chkFemenino.Checked = False
        chkActivo.Checked = False
        chkInactivo.Checked = False
        chkOrdenCedula.Checked = True ' Orden predeterminado por cédula
        chkOrdenNombre.Checked = False
    End Sub

    ' Método para validar los campos antes de ejecutar cualquier acción
    Private Function ValidarCampos() As Boolean
        ' Validar que los campos no estén vacíos
        If String.IsNullOrWhiteSpace(txtCedula.Text) OrElse
           String.IsNullOrWhiteSpace(txtNombre.Text) OrElse
           String.IsNullOrWhiteSpace(txtApellido.Text) OrElse
           String.IsNullOrWhiteSpace(txtDireccion.Text) OrElse
           String.IsNullOrWhiteSpace(txtCelular.Text) OrElse
           String.IsNullOrWhiteSpace(txtCorreo.Text) Then
            MessageBox.Show("Todos los campos son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Validar el formato del número de celular
        Dim celularSinGuiones As String = txtCelular.Text.Replace("-", "").Trim()
        If Not IsNumeric(celularSinGuiones) OrElse celularSinGuiones.Length <> 8 Then
            MessageBox.Show("El número de celular debe tener exactamente 8 dígitos (sin contar guiones).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        ' Validar el formato del correo electrónico
        If Not txtCorreo.Text.Contains("@") OrElse Not txtCorreo.Text.Contains(".") Then
            MessageBox.Show("El correo electrónico no tiene un formato válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If

        Return True
    End Function
End Class
