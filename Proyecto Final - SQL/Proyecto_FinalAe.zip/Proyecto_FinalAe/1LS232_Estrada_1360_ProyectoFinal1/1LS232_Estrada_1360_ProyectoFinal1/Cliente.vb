﻿Public Class Cliente
    Public Property Id As Integer
    Public Property Cedula As String
    Public Property Nombre As String
    Public Property Apellido As String
    Public Property Direccion As String
    Public Property Celular As String
    Public Property Correo As String
    Public Property Sexo As Char
    Public Property Estatus As Char
End Class
