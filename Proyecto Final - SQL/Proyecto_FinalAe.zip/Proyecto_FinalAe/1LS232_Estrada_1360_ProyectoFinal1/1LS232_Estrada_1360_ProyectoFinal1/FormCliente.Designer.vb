﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormCliente
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        txtCedula = New TextBox()
        Label1 = New Label()
        txtNombre = New TextBox()
        Label2 = New Label()
        txtApellido = New TextBox()
        Label3 = New Label()
        txtDireccion = New TextBox()
        Label4 = New Label()
        Label5 = New Label()
        txtCelular = New TextBox()
        txtCorreo = New TextBox()
        Label6 = New Label()
        Label7 = New Label()
        Label9 = New Label()
        btnBuscar = New Button()
        btnAgregar = New Button()
        btnModificar = New Button()
        btnEliminar = New Button()
        btnLimpiar = New Button()
        btnListar = New Button()
        dgvClientes = New DataGridView()
        Label10 = New Label()
        chkMasculino = New CheckBox()
        chkFemenino = New CheckBox()
        chkActivo = New CheckBox()
        chkInactivo = New CheckBox()
        chkOrdenCedula = New CheckBox()
        chkOrdenNombre = New CheckBox()
        SqlCommand1 = New Microsoft.Data.SqlClient.SqlCommand()
        CType(dgvClientes, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' txtCedula
        ' 
        txtCedula.Location = New Point(21, 38)
        txtCedula.Name = "txtCedula"
        txtCedula.Size = New Size(125, 27)
        txtCedula.TabIndex = 0
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Location = New Point(173, 45)
        Label1.Name = "Label1"
        Label1.Size = New Size(55, 20)
        Label1.TabIndex = 1
        Label1.Text = "Cédula"
        ' 
        ' txtNombre
        ' 
        txtNombre.Location = New Point(21, 84)
        txtNombre.Name = "txtNombre"
        txtNombre.Size = New Size(125, 27)
        txtNombre.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Location = New Point(173, 91)
        Label2.Name = "Label2"
        Label2.Size = New Size(64, 20)
        Label2.TabIndex = 3
        Label2.Text = "Nombre"
        ' 
        ' txtApellido
        ' 
        txtApellido.Location = New Point(21, 128)
        txtApellido.Name = "txtApellido"
        txtApellido.Size = New Size(125, 27)
        txtApellido.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(173, 135)
        Label3.Name = "Label3"
        Label3.Size = New Size(66, 20)
        Label3.TabIndex = 5
        Label3.Text = "Apellido"
        ' 
        ' txtDireccion
        ' 
        txtDireccion.Location = New Point(21, 175)
        txtDireccion.Name = "txtDireccion"
        txtDireccion.Size = New Size(125, 27)
        txtDireccion.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Location = New Point(173, 182)
        Label4.Name = "Label4"
        Label4.Size = New Size(72, 20)
        Label4.TabIndex = 7
        Label4.Text = "Dirección"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Location = New Point(173, 226)
        Label5.Name = "Label5"
        Label5.Size = New Size(55, 20)
        Label5.TabIndex = 8
        Label5.Text = "Celular"
        ' 
        ' txtCelular
        ' 
        txtCelular.Location = New Point(21, 219)
        txtCelular.Name = "txtCelular"
        txtCelular.Size = New Size(125, 27)
        txtCelular.TabIndex = 9
        ' 
        ' txtCorreo
        ' 
        txtCorreo.Location = New Point(21, 266)
        txtCorreo.Name = "txtCorreo"
        txtCorreo.Size = New Size(125, 27)
        txtCorreo.TabIndex = 10
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Location = New Point(173, 273)
        Label6.Name = "Label6"
        Label6.Size = New Size(54, 20)
        Label6.TabIndex = 11
        Label6.Text = "Correo"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Location = New Point(26, 315)
        Label7.Name = "Label7"
        Label7.Size = New Size(41, 20)
        Label7.TabIndex = 12
        Label7.Text = "Sexo"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Location = New Point(173, 315)
        Label9.Name = "Label9"
        Label9.Size = New Size(55, 20)
        Label9.TabIndex = 16
        Label9.Text = "Estatus"
        ' 
        ' btnBuscar
        ' 
        btnBuscar.Location = New Point(694, 36)
        btnBuscar.Name = "btnBuscar"
        btnBuscar.Size = New Size(94, 29)
        btnBuscar.TabIndex = 19
        btnBuscar.Text = "Buscar"
        btnBuscar.UseVisualStyleBackColor = True
        ' 
        ' btnAgregar
        ' 
        btnAgregar.Location = New Point(694, 84)
        btnAgregar.Name = "btnAgregar"
        btnAgregar.Size = New Size(94, 29)
        btnAgregar.TabIndex = 20
        btnAgregar.Text = "Agregar"
        btnAgregar.UseVisualStyleBackColor = True
        ' 
        ' btnModificar
        ' 
        btnModificar.Location = New Point(694, 131)
        btnModificar.Name = "btnModificar"
        btnModificar.Size = New Size(94, 29)
        btnModificar.TabIndex = 21
        btnModificar.Text = "Modificar"
        btnModificar.UseVisualStyleBackColor = True
        ' 
        ' btnEliminar
        ' 
        btnEliminar.Location = New Point(694, 178)
        btnEliminar.Name = "btnEliminar"
        btnEliminar.Size = New Size(94, 29)
        btnEliminar.TabIndex = 22
        btnEliminar.Text = "Eliminar"
        btnEliminar.UseVisualStyleBackColor = True
        ' 
        ' btnLimpiar
        ' 
        btnLimpiar.Location = New Point(694, 222)
        btnLimpiar.Name = "btnLimpiar"
        btnLimpiar.Size = New Size(94, 29)
        btnLimpiar.TabIndex = 23
        btnLimpiar.Text = "Limpiar"
        btnLimpiar.UseVisualStyleBackColor = True
        ' 
        ' btnListar
        ' 
        btnListar.Location = New Point(694, 269)
        btnListar.Name = "btnListar"
        btnListar.Size = New Size(94, 29)
        btnListar.TabIndex = 24
        btnListar.Text = "Listar"
        btnListar.UseVisualStyleBackColor = True
        ' 
        ' dgvClientes
        ' 
        dgvClientes.AllowUserToOrderColumns = True
        dgvClientes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        dgvClientes.Location = New Point(251, 45)
        dgvClientes.Name = "dgvClientes"
        dgvClientes.RowHeadersWidth = 51
        dgvClientes.Size = New Size(427, 248)
        dgvClientes.TabIndex = 25
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Location = New Point(346, 319)
        Label10.Name = "Label10"
        Label10.Size = New Size(90, 20)
        Label10.TabIndex = 26
        Label10.Text = "Ordenar por"
        ' 
        ' chkMasculino
        ' 
        chkMasculino.AutoSize = True
        chkMasculino.Location = New Point(26, 338)
        chkMasculino.Name = "chkMasculino"
        chkMasculino.Size = New Size(98, 24)
        chkMasculino.TabIndex = 29
        chkMasculino.Text = "Masculino"
        chkMasculino.UseVisualStyleBackColor = True
        ' 
        ' chkFemenino
        ' 
        chkFemenino.AutoSize = True
        chkFemenino.Location = New Point(26, 359)
        chkFemenino.Name = "chkFemenino"
        chkFemenino.Size = New Size(96, 24)
        chkFemenino.TabIndex = 30
        chkFemenino.Text = "Femenino"
        chkFemenino.UseVisualStyleBackColor = True
        ' 
        ' chkActivo
        ' 
        chkActivo.AutoSize = True
        chkActivo.Location = New Point(173, 338)
        chkActivo.Name = "chkActivo"
        chkActivo.Size = New Size(73, 24)
        chkActivo.TabIndex = 31
        chkActivo.Text = "Activo"
        chkActivo.UseVisualStyleBackColor = True
        ' 
        ' chkInactivo
        ' 
        chkInactivo.AutoSize = True
        chkInactivo.Location = New Point(173, 358)
        chkInactivo.Name = "chkInactivo"
        chkInactivo.Size = New Size(83, 24)
        chkInactivo.TabIndex = 32
        chkInactivo.Text = "Inactivo"
        chkInactivo.UseVisualStyleBackColor = True
        ' 
        ' chkOrdenCedula
        ' 
        chkOrdenCedula.AutoSize = True
        chkOrdenCedula.Location = New Point(346, 338)
        chkOrdenCedula.Name = "chkOrdenCedula"
        chkOrdenCedula.Size = New Size(77, 24)
        chkOrdenCedula.TabIndex = 33
        chkOrdenCedula.Text = "Cédula"
        chkOrdenCedula.UseVisualStyleBackColor = True
        ' 
        ' chkOrdenNombre
        ' 
        chkOrdenNombre.AutoSize = True
        chkOrdenNombre.Location = New Point(346, 358)
        chkOrdenNombre.Name = "chkOrdenNombre"
        chkOrdenNombre.Size = New Size(86, 24)
        chkOrdenNombre.TabIndex = 34
        chkOrdenNombre.Text = "Nombre"
        chkOrdenNombre.UseVisualStyleBackColor = True
        ' 
        ' SqlCommand1
        ' 
        SqlCommand1.CommandTimeout = 30
        SqlCommand1.EnableOptimizedParameterBinding = False
        ' 
        ' FormCliente
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 450)
        Controls.Add(chkOrdenNombre)
        Controls.Add(chkOrdenCedula)
        Controls.Add(chkInactivo)
        Controls.Add(chkActivo)
        Controls.Add(chkFemenino)
        Controls.Add(chkMasculino)
        Controls.Add(Label10)
        Controls.Add(dgvClientes)
        Controls.Add(btnListar)
        Controls.Add(btnLimpiar)
        Controls.Add(btnEliminar)
        Controls.Add(btnModificar)
        Controls.Add(btnAgregar)
        Controls.Add(btnBuscar)
        Controls.Add(Label9)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(txtCorreo)
        Controls.Add(txtCelular)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(txtDireccion)
        Controls.Add(Label3)
        Controls.Add(txtApellido)
        Controls.Add(Label2)
        Controls.Add(txtNombre)
        Controls.Add(Label1)
        Controls.Add(txtCedula)
        Name = "FormCliente"
        Text = "FormCliente"
        CType(dgvClientes, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents txtCedula As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtNombre As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtApellido As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtDireccion As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtCelular As TextBox
    Friend WithEvents txtCorreo As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents btnBuscar As Button
    Friend WithEvents btnAgregar As Button
    Friend WithEvents btnModificar As Button
    Friend WithEvents btnEliminar As Button
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnListar As Button
    Friend WithEvents dgvClientes As DataGridView
    Friend WithEvents Label10 As Label
    Friend WithEvents chkMasculino As CheckBox
    Friend WithEvents chkFemenino As CheckBox
    Friend WithEvents chkActivo As CheckBox
    Friend WithEvents chkInactivo As CheckBox
    Friend WithEvents chkOrdenCedula As CheckBox
    Friend WithEvents chkOrdenNombre As CheckBox
    Friend WithEvents SqlCommand1 As Microsoft.Data.SqlClient.SqlCommand
End Class
