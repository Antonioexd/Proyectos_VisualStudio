﻿Imports System.Data.SqlClient

Public Class BD
    ' Cadena de conexión a la base de datos
    Private connectionString As String = "Data Source=Antonio123\MSSQLSERVER01;Initial Catalog=GestorDB;Integrated Security=True"

    ' Método para ejecutar un procedimiento almacenado que devuelve un DataTable
    Public Function EjecutarSP(nombreSP As String, parametros As List(Of SqlParameter)) As DataTable
        Dim dt As New DataTable()
        Try
            Using conn As New SqlConnection(connectionString) ' Establece la conexión
                Using cmd As New SqlCommand(nombreSP, conn)
                    cmd.CommandType = CommandType.StoredProcedure

                    ' Agrega los parámetros si existen
                    If parametros IsNot Nothing Then
                        cmd.Parameters.AddRange(parametros.ToArray())
                    End If

                    ' Usa SqlDataAdapter para llenar el DataTable
                    Dim da As New SqlDataAdapter(cmd)
                    da.Fill(dt)
                End Using
            End Using
        Catch ex As SqlException
            ' Manejo específico para errores de SQL
            Throw New Exception("Error SQL al ejecutar el procedimiento almacenado '" & nombreSP & "': " & ex.Message)
        Catch ex As Exception
            ' Manejo genérico para otros errores
            Throw New Exception("Error general al ejecutar el procedimiento almacenado '" & nombreSP & "': " & ex.Message)
        End Try
        Return dt
    End Function

    ' Método para ejecutar un procedimiento almacenado que no devuelve datos (INSERT, UPDATE, DELETE)
    Public Sub EjecutarSPNonQuery(nombreSP As String, parametros As List(Of SqlParameter))
        Try
            Using conn As New SqlConnection(connectionString) ' Establece la conexión
                Using cmd As New SqlCommand(nombreSP, conn)
                    cmd.CommandType = CommandType.StoredProcedure

                    ' Agrega los parámetros si existen
                    If parametros IsNot Nothing Then
                        cmd.Parameters.AddRange(parametros.ToArray())
                    End If

                    ' Abre la conexión y ejecuta el comando
                    conn.Open()
                    cmd.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As SqlException
            ' Manejo específico para errores de SQL
            Throw New Exception("Error SQL al ejecutar el procedimiento almacenado '" & nombreSP & "': " & ex.Message)
        Catch ex As Exception
            ' Manejo genérico para otros errores
            Throw New Exception("Error general al ejecutar el procedimiento almacenado '" & nombreSP & "': " & ex.Message)
        End Try
    End Sub

    ' Método para probar la conexión a la base de datos
    Public Function ProbarConexion() As Boolean
        Try
            Using conn As New SqlConnection(connectionString)
                conn.Open() ' Intenta abrir la conexión
                Return True ' Conexión exitosa
            End Using
        Catch ex As SqlException
            ' Manejo específico para errores de conexión SQL
            Throw New Exception("Error al conectar con la base de datos (SQL): " & ex.Message)
        Catch ex As Exception
            ' Manejo genérico para otros errores
            Throw New Exception("Error al conectar con la base de datos: " & ex.Message)
        End Try
    End Function

    ' Método opcional para ejecutar un procedimiento almacenado que devuelve un único valor (e.g., COUNT, SUM)
    Public Function EjecutarSPScalar(nombreSP As String, parametros As List(Of SqlParameter)) As Object
        Try
            Using conn As New SqlConnection(connectionString)
                Using cmd As New SqlCommand(nombreSP, conn)
                    cmd.CommandType = CommandType.StoredProcedure

                    ' Agrega los parámetros si existen
                    If parametros IsNot Nothing Then
                        cmd.Parameters.AddRange(parametros.ToArray())
                    End If

                    ' Abre la conexión y ejecuta el comando
                    conn.Open()
                    Return cmd.ExecuteScalar() ' Devuelve el valor único
                End Using
            End Using
        Catch ex As SqlException
            ' Manejo específico para errores de SQL
            Throw New Exception("Error SQL al ejecutar el procedimiento almacenado '" & nombreSP & "': " & ex.Message)
        Catch ex As Exception
            ' Manejo genérico para otros errores
            Throw New Exception("Error general al ejecutar el procedimiento almacenado '" & nombreSP & "': " & ex.Message)
        End Try
    End Function
End Class
