﻿Public Class FormPresentacion
    Inherits Form ' Hereda de System.Windows.Forms.Form para ser un formulario válido

    ' Constructor del formulario
    Public Sub New()
        InitializeComponent() ' Inicializa los componentes visuales del formulario
    End Sub

    ' Inicialización de componentes
    Private Sub InitializeComponent()
        lblTitulo = New Label()
        lblDescripcion = New Label()
        lblAutor = New Label()
        SuspendLayout()
        ' 
        ' lblTitulo
        ' 
        lblTitulo.Dock = DockStyle.Top
        lblTitulo.Font = New Font("Arial", 10.0F, FontStyle.Bold)
        lblTitulo.Location = New Point(0, 40)
        lblTitulo.Name = "lblTitulo"
        lblTitulo.Size = New Size(482, 25)
        lblTitulo.TabIndex = 0
        lblTitulo.Text = "Sistema de Gestión de Clientes y Productos"
        lblTitulo.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblDescripcion
        ' 
        lblDescripcion.Dock = DockStyle.Top
        lblDescripcion.Font = New Font("Arial", 10.0F)
        lblDescripcion.Location = New Point(0, 0)
        lblDescripcion.Name = "lblDescripcion"
        lblDescripcion.Size = New Size(482, 40)
        lblDescripcion.TabIndex = 1
        lblDescripcion.Text = "Este sistema permite administrar información de clientes y productos."
        lblDescripcion.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblAutor
        ' 
        lblAutor.Dock = DockStyle.Bottom
        lblAutor.Font = New Font("Arial", 10.0F, FontStyle.Italic)
        lblAutor.Location = New Point(0, 223)
        lblAutor.Name = "lblAutor"
        lblAutor.Size = New Size(482, 30)
        lblAutor.TabIndex = 2
        lblAutor.Text = "Desarrollado por: Antonio Estrada (Cedula 3-752-1360)"
        lblAutor.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' FormPresentacion
        ' 
        ClientSize = New Size(482, 253)
        Controls.Add(lblTitulo)
        Controls.Add(lblDescripcion)
        Controls.Add(lblAutor)
        FormBorderStyle = FormBorderStyle.FixedDialog
        MaximizeBox = False
        Name = "FormPresentacion"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Pantalla de Presentación"
        ResumeLayout(False)
    End Sub

    ' Evento de carga del formulario
    Private Sub FormPresentacion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Mensaje opcional al cargar el formulario
        MessageBox.Show("Bienvenido al Sistema de Gestión de Clientes y Productos.", "Bienvenido", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Friend WithEvents lblTitulo As Label
    Friend WithEvents lblDescripcion As Label
    Friend WithEvents lblAutor As Label
End Class
